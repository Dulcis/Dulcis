<?php
	//インクルードのパス設定
	ini_set('include_path', '/jyoko3dev/xampp/htdocs/prototype/classes/');
?>