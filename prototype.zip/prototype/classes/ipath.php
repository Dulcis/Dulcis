<?php
	//画像のパス
	define('ipath', '/prototype/ref/img/');
?>